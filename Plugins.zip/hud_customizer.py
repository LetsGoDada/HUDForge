import tkinter as tk
from tkinter import colorchooser, ttk


def register(app, notebook):
  # 1. Create top-level tab
  tab = tk.Frame(notebook, bg="#161925")
  notebook.add(tab, text="🎨 HUD Customizer")

  # Register this tab for global theme updates
  if hasattr(app, "register_theme_frame"):
    app.register_theme_frame(tab)

  # 2. Title & Description
  title_lbl = tk.Label(
      tab,
      text="Global HUD Customizer",
      fg="#00d2ff",
      bg="#161925",
      font=("Consolas", 11, "bold"),
  )
  title_lbl.pack(anchor="w", padx=15, pady=(12, 2))

  # 3. Controls Container Frame
  controls_frame = tk.Frame(tab, bg="#161925")
  controls_frame.pack(anchor="w", padx=15, pady=5)

  # --- Feature A: Change Window Name / Title ---
  title_frame = tk.Frame(controls_frame, bg="#161925")
  title_frame.pack(anchor="w", fill="x", pady=5)

  title_input_lbl = tk.Label(
      title_frame,
      text="Window Title:",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9),
  )
  title_input_lbl.pack(side="left", padx=(0, 8))

  title_entry = tk.Entry(
      title_frame,
      bg="#12151e",
      fg="#ffffff",
      insertbackground="white",
      font=("Consolas", 9),
      bd=1,
      relief="solid",
      width=25,
  )
  title_entry.insert(0, "HUDForge v1.0")
  title_entry.pack(side="left", padx=5)

  def apply_window_title():
    new_title = title_entry.get()
    if new_title:
      app.title(new_title)

  title_btn = tk.Button(
      title_frame,
      text="SET TITLE",
      command=apply_window_title,
      bg="#212738",
      fg="#00d2ff",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 8, "bold"),
      bd=0,
      padx=8,
      pady=4,
      cursor="hand2",
  )
  title_btn.pack(side="left", padx=5)

  # --- Feature B: Global Background Color (App + All Plugins) ---
  def change_global_background():
    color = colorchooser.askcolor(
        title="Choose Global Background Color", color="#0d0f18"
    )
    if color[1]:
      if hasattr(app, "set_global_background"):
        app.set_global_background(color[1])
      else:
        app.configure(bg=color[1])
        tab.configure(bg=color[1])
        controls_frame.configure(bg=color[1])

  bg_btn = tk.Button(
      controls_frame,
      text="🎨 CHANGE GLOBAL APP & PLUGIN COLOR",
      command=change_global_background,
      bg="#212738",
      fg="#00ffb3",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  bg_btn.pack(anchor="w", padx=0, pady=8)  # Fixed: removed invalid sticky option

  # --- Feature C: Window Opacity / Transparency Slider ---
  def update_opacity(val):
    try:
      app.attributes("-alpha", float(val))
    except Exception:
      pass

  opacity_lbl = tk.Label(
      controls_frame,
      text="Window Opacity (Transparency):",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9),
  )
  opacity_lbl.pack(anchor="w", padx=0, pady=(8, 2))

  opacity_slider = ttk.Scale(
      controls_frame,
      from_=0.3,
      to=1.0,
      value=1.0,
      command=update_opacity,
      orient="horizontal",
      length=280,
  )
  opacity_slider.pack(anchor="w", padx=0, pady=2)

  # --- Feature D: Reset Defaults ---
  def reset_defaults():
    if hasattr(app, "set_global_background"):
      app.set_global_background("#0d0f18")
    app.attributes("-alpha", 1.0)
    app.title("HUDForge v1.0")
    title_entry.delete(0, tk.END)
    title_entry.insert(0, "HUDForge v1.0")
    opacity_slider.set(1.0)

  reset_btn = tk.Button(
      controls_frame,
      text="🔄 RESET DEFAULTS",
      command=reset_defaults,
      bg="#382127",
      fg="#ff5555",
      activebackground="#482a32",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  reset_btn.pack(anchor="w", padx=0, pady=(12, 5))  # Fixed: removed sticky