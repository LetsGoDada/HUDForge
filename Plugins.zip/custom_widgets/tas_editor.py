import os
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
  import keyboard

  HAS_KEYBOARD = True
except ImportError:
  HAS_KEYBOARD = False


def register(app, sub_notebook):
  # 1. Create the sub-tab inside Custom Hub
  tab = tk.Frame(sub_notebook, bg="#161925")
  sub_notebook.add(tab, text="⚡ TAS & Macro Editor")

  # Register for global theme sync with HUD Customizer
  if hasattr(app, "register_theme_frame"):
    app.register_theme_frame(tab)

  # 2. Title & Description
  title_lbl = tk.Label(
      tab,
      text="TAS Player & LLI (Locked Legit Inputs) Importer",
      fg="#00d2ff",
      bg="#161925",
      font=("Consolas", 11, "bold"),
  )
  title_lbl.pack(anchor="w", padx=15, pady=(15, 5))

  desc_lbl = tk.Label(
      tab,
      text=(
          "Import secure LLI logs, parse inputs into an editable timeline,"
          " resave locally, and playback macros."
      ),
      fg="#8f9ba8",
      bg="#161925",
      font=("Segoe UI", 9),
      justify="left",
  )
  desc_lbl.pack(anchor="w", padx=15, pady=(0, 10))

  # 3. Main Layout Container
  content_frame = tk.Frame(tab, bg="#161925")
  content_frame.pack(fill="both", expand=True, padx=15, pady=5)

  # Left Column: Input Builder & LLI Importer Controls
  left_col = tk.Frame(content_frame, bg="#161925")
  left_col.pack(side="left", fill="y", padx=(0, 15))

  # Section Header: LLI Import
  lbl_import = tk.Label(
      left_col,
      text="-- LLI File Import --",
      fg="#00ffb3",
      bg="#161925",
      font=("Consolas", 9, "bold"),
  )
  lbl_import.pack(anchor="w", pady=(0, 5))

  sequence_data = []  # Stores tuples: (key_or_action, delay_ms)

  # Function to parse LLI files
  def import_lli_file():
    file_path = filedialog.askopenfilename(
        title="Select LLI Proof Log",
        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
    )
    if not file_path:
      return

    try:
      with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

      temp_sequence = []

      for line in lines:
        line_str = line.strip()
        # Look for timestamp input log format e.g., [20:36:28.318] | MOUSE_LEFT_DOWN | Physical: Button.left (Mapped: BREAK)
        if line_str.startswith("[") and "|" in line_str:
          parts = line_str.split("|")
          if len(parts) >= 2:
            action_type = parts[1].strip()
            temp_sequence.append(
                (action_type, "50")
            )  # Default tick delay 50ms

      if temp_sequence:
        # Prompt user to resave locally because original LLI is read-only / unwriteable
        save_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt")],
            title="Resave Editable LLI Copy Locally",
            initialfile="editable_lli_sequence.txt",
        )
        if save_path:
          with open(save_path, "w", encoding="utf-8") as sf:
            sf.writelines(lines)  # Resave full original content securely

          # Load into UI listbox
          sequence_data.clear()
          listbox.delete(0, tk.END)
          for act, dly in temp_sequence:
            sequence_data.append((act, dly))
            listbox.insert(tk.END, f"ACTION: {act} | DELAY: {dly}ms")

          messagebox.showinfo(
              "LLI Import Successful",
              f"Successfully imported {len(temp_sequence)} inputs!\nResaved"
              f" editable copy to:\n{save_path}",
          )
      else:
        messagebox.showwarning(
            "Parse Warning",
            "No valid input lines found in the selected LLI file structure.",
        )
    except Exception as e:
      messagebox.showerror(
          "Import Error", f"Failed to parse LLI file:\n{str(e)}"
      )

  import_btn = tk.Button(
      left_col,
      text="📂 IMPORT LLI FILE...",
      command=import_lli_file,
      bg="#212738",
      fg="#00ffb3",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 8, "bold"),
      bd=0,
      padx=10,
      pady=6,
      cursor="hand2",
  )
  import_btn.pack(anchor="w", fill="x", pady=(0, 15))

  # Manual Input Builder Header
  lbl_manual = tk.Label(
      left_col,
      text="-- Manual Builder --",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9, "bold"),
  )
  lbl_manual.pack(anchor="w", pady=(0, 2))

  lbl_action = tk.Label(
      left_col,
      text="Command / Key:",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9),
  )
  lbl_action.pack(anchor="w", pady=(0, 2))

  key_entry = tk.Entry(
      left_col,
      bg="#12151e",
      fg="#ffffff",
      insertbackground="white",
      font=("Consolas", 9),
      bd=1,
      relief="solid",
      width=18,
  )
  key_entry.insert(0, "space")
  key_entry.pack(anchor="w", pady=(0, 8))

  lbl_delay = tk.Label(
      left_col,
      text="Delay After (ms):",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9),
  )
  lbl_delay.pack(anchor="w", pady=(0, 2))

  delay_entry = tk.Entry(
      left_col,
      bg="#12151e",
      fg="#ffffff",
      insertbackground="white",
      font=("Consolas", 9),
      bd=1,
      relief="solid",
      width=18,
  )
  delay_entry.insert(0, "50")
  delay_entry.pack(anchor="w", pady=(0, 10))

  def add_action():
    key = key_entry.get().strip()
    delay = delay_entry.get().strip()
    if not key or not delay:
      return
    item_str = f"ACTION: {key} | DELAY: {delay}ms"
    sequence_data.append((key, delay))
    listbox.insert(tk.END, item_str)

  def remove_action():
    selected = listbox.curselection()
    if selected:
      idx = selected[0]
      listbox.delete(idx)
      sequence_data.pop(idx)

  def clear_sequence():
    sequence_data.clear()
    listbox.delete(0, tk.END)

  add_btn = tk.Button(
      left_col,
      text="➕ ADD MANUAL ACTION",
      command=add_action,
      bg="#212738",
      fg="#e0e6ed",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 8, "bold"),
      bd=0,
      padx=10,
      pady=5,
      cursor="hand2",
  )
  add_btn.pack(anchor="w", fill="x", pady=3)

  rem_btn = tk.Button(
      left_col,
      text="❌ REMOVE SELECTED",
      command=remove_action,
      bg="#382127",
      fg="#ff5555",
      activebackground="#482a32",
      activeforeground="#ffffff",
      font=("Consolas", 8, "bold"),
      bd=0,
      padx=10,
      pady=5,
      cursor="hand2",
  )
  rem_btn.pack(anchor="w", fill="x", pady=3)

  clr_btn = tk.Button(
      left_col,
      text="🗑 CLEAR ALL",
      command=clear_sequence,
      bg="#212738",
      fg="#ff9999",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 8, "bold"),
      bd=0,
      padx=10,
      pady=5,
      cursor="hand2",
  )
  clr_btn.pack(anchor="w", fill="x", pady=3)

  # Right Column: Sequence Display & Playback
  right_col = tk.Frame(content_frame, bg="#161925")
  right_col.pack(side="left", fill="both", expand=True)

  lbl_seq = tk.Label(
      right_col,
      text="Execution Timeline:",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9),
  )
  lbl_seq.pack(anchor="w", pady=(0, 2))

  list_frame = tk.Frame(right_col, bg="#161925")
  list_frame.pack(fill="both", expand=True, pady=(0, 10))

  listbox = tk.Listbox(
      list_frame,
      bg="#12151e",
      fg="#00ffb3",
      selectbackground="#212738",
      selectforeground="#ffffff",
      font=("Consolas", 9),
      bd=1,
      relief="solid",
      height=15,
  )
  listbox.pack(side="left", fill="both", expand=True)

  scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
  scrollbar.pack(side="right", fill="y")
  listbox.config(yscrollcommand=scrollbar.set)

  # Playback Engine
  def play_sequence():
    if not sequence_data:
      messagebox.showwarning(
          "Empty Sequence", "Import an LLI file or add actions to the timeline first!"
      )
      return
    if not HAS_KEYBOARD:
      messagebox.showerror(
          "Missing Library",
          "Please install the 'keyboard' package: pip install keyboard",
      )
      return

    def run_macro():
      for i in range(3, 0, -1):
        time.sleep(1)

      for act, delay_ms in sequence_data:
        try:
          if not ("KEY_" in act or "MOUSE_" in act):
            keyboard.send(act)
          time.sleep(int(delay_ms) / 1000.0)
        except Exception:
          pass

    import threading

    threading.Thread(target=run_macro, daemon=True).start()
    messagebox.showinfo(
        "TAS Running", "Sequence started! Switch to your game window."
    )

  play_btn = tk.Button(
      right_col,
      text="▶ PLAY TIMELINE (3s Countdown)",
      command=play_sequence,
      bg="#212738",
      fg="#00d2ff",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  play_btn.pack(anchor="w")