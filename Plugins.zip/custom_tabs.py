import importlib.util
import os
import sys
import traceback
import tkinter as tk
from tkinter import ttk

# Pfad zum Haupt-Projektverzeichnis und dem Unterordner 'custom_widgets'
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CUSTOM_WIDGETS_DIR = os.path.join(PROJECT_ROOT, "custom_widgets")


def register(app, notebook):
  # 1. Haupt-Tab für den Custom Hub erstellen
  main_tab = tk.Frame(notebook, bg="#161925")
  notebook.add(main_tab, text="📦 Custom Hub")

  # Registriere den Haupt-Tab für globale Theme-Änderungen
  if hasattr(app, "register_theme_frame"):
    app.register_theme_frame(main_tab)

  # 2. Unter-Notebook (Tab-Gruppe) für alle Widgets im Custom Hub
  sub_notebook = ttk.Notebook(main_tab)
  sub_notebook.pack(fill="both", expand=True, padx=6, pady=6)

  # 3. Sicherstellen, dass der 'custom_widgets'-Ordner existiert
  if not os.path.exists(CUSTOM_WIDGETS_DIR):
    os.makedirs(CUSTOM_WIDGETS_DIR)

  # 4. Alle Python-Dateien im 'custom_widgets'-Ordner automatisch laden
  for filename in sorted(os.listdir(CUSTOM_WIDGETS_DIR)):
    if filename.endswith(".py") and not filename.startswith("_"):
      widget_name = filename[:-3]
      file_path = os.path.join(CUSTOM_WIDGETS_DIR, filename)

      try:
        spec = importlib.util.spec_from_file_location(widget_name, file_path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[widget_name] = module
        spec.loader.exec_module(module)

        # Flexible Übergabe (unterstützt register mit app/sub_notebook oder nur sub_notebook)
        if hasattr(module, "register"):
          try:
            # Versuche, das Widget zu registrieren und fange erstellte Frames ab
            module.register(app, sub_notebook)
          except TypeError:
            try:
              module.register(sub_notebook)
            except TypeError:
              module.register()
        else:
          print(
              f"[CustomHub] Hinweis: '{widget_name}' besitzt keine"
              " 'register'-Funktion."
          )

      except Exception as e:
        print(
            f"[CustomHub Error] Fehler beim Laden des Widgets '{widget_name}':"
            f" {e}"
        )
        traceback.print_exc()

  # Automatisch alle erstellten Unter-Tabs im sub_notebook für das Theme-System registrieren
  def update_sub_notebook_theme(color):
    try:
      for tab_id in sub_notebook.tabs():
        tab_frame = sub_notebook.nametowidget(tab_id)
        tab_frame.configure(bg=color)
        for child in tab_frame.winfo_children():
          try:
            if isinstance(child, (tk.Frame, tk.Label)):
              child.configure(bg=color)
          except Exception:
            pass
    except Exception:
      pass

  # Wir hängen uns an den Farbwechsel an, falls die App das unterstützt
  # (Die Unter-Tabs werden dadurch automatisch mitgefärbt)