from collections import deque
import os
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

# Try importing screen capture and video libraries
try:
  import cv2
  import mss
  import numpy as np

  HAS_RECORDER_DEPS = True
except ImportError:
  HAS_RECORDER_DEPS = False

try:
  import keyboard

  HAS_KEYBOARD = True
except ImportError:
  HAS_KEYBOARD = False


def register(app, sub_notebook):
  # 1. Create the sub-tab inside Custom Hub
  tab = tk.Frame(sub_notebook, bg="#161925")
  sub_notebook.add(tab, text="🎬 Insta Screenrecord")

  # Register for global theme sync with HUD Customizer
  if hasattr(app, "register_theme_frame"):
    app.register_theme_frame(tab)

  # 2. Title & Description
  title_lbl = tk.Label(
      tab,
      text="Insta Screenrecord (Instant Replay)",
      fg="#00d2ff",
      bg="#161925",
      font=("Consolas", 11, "bold"),
  )
  title_lbl.pack(anchor="w", padx=15, pady=(15, 5))

  desc_text = (
      "Continuously buffers your screen in the background.\nPress the hotkey"
      " or click save to export the last 1 minute of footage."
  )
  if not HAS_RECORDER_DEPS:
    desc_text += (
        "\n⚠️ Warning: 'mss' and 'opencv-python' are missing. Run: pip install"
        " mss opencv-python keyboard"
    )

  desc_lbl = tk.Label(
      tab,
      text=desc_text,
      fg="#ff9999" if not HAS_RECORDER_DEPS else "#8f9ba8",
      bg="#161925",
      font=("Segoe UI", 9),
      justify="left",
  )
  desc_lbl.pack(anchor="w", padx=15, pady=(0, 15))

  # 3. Controls Container
  controls_frame = tk.Frame(tab, bg="#161925")
  controls_frame.pack(anchor="w", padx=15, pady=5)

  # Status Indicator
  status_var = tk.StringVar(value="Status: INACTIVE (Buffer Stopped)")
  status_lbl = tk.Label(
      controls_frame,
      textvariable=status_var,
      fg="#ff5555",
      bg="#161925",
      font=("Consolas", 9, "bold"),
  )
  status_lbl.pack(anchor="w", pady=(0, 10))

  # Hotkey configuration
  hk_frame = tk.Frame(controls_frame, bg="#161925")
  hk_frame.pack(anchor="w", fill="x", pady=5)

  hk_label = tk.Label(
      hk_frame,
      text="Save Hotkey:",
      fg="#e0e6ed",
      bg="#161925",
      font=("Consolas", 9),
  )
  hk_label.pack(side="left", padx=(0, 8))

  hk_entry = tk.Entry(
      hk_frame,
      bg="#12151e",
      fg="#ffffff",
      insertbackground="white",
      font=("Consolas", 9),
      bd=1,
      relief="solid",
      width=15,
  )
  hk_entry.insert(0, "f10")
  hk_entry.pack(side="left", padx=5)

  # Recorder Engine State
  recorder_state = {
      "running": False,
      "buffer": deque(
          maxlen=300
      ),  # 60 seconds buffer at ~5 FPS to save memory/CPU
      "fps": 5,
      "thread": None,
  }

  def buffer_worker():
    with mss.mss() as sct:
      monitor = sct.monitors[2]  # Primary monitor
      while recorder_state["running"]:
        start_time = time.time()
        img = np.array(sct.grab(monitor))
        # Fixed: using cv2.COLOR_BGRA2BGR instead of BGRA2BGR
        frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
        recorder_state["buffer"].append(frame)

        # Control framerate (~5 FPS for a lightweight 1-minute buffer)
        elapsed = time.time() - start_time
        sleep_time = max(0, (1.0 / recorder_state["fps"]) - elapsed)
        time.sleep(sleep_time)

  def save_replay():
    if not HAS_RECORDER_DEPS:
      messagebox.showerror(
          "Missing Dependencies",
          "Please install mss and opencv-python first!",
      )
      return

    buffer_data = list(recorder_state["buffer"])
    if not buffer_data:
      messagebox.showwarning(
          "Buffer Empty",
          "Recording buffer is empty. Start the recorder first!",
      )
      return

    try:
      desktop = os.path.join(os.path.expanduser("~"), "Desktop")
      filename = os.path.join(
          desktop,
          f"HUDForge_Replay_{time.strftime('%Y%m%d_%H%M%S')}.mp4",
      )

      height, width, _ = buffer_data[0].shape
      fourcc = cv2.VideoWriter_fourcc(*"mp4v")
      out = cv2.VideoWriter(
          filename, fourcc, recorder_state["fps"], (width, height)
      )

      for frame in buffer_data:
        out.write(frame)
      out.release()

      messagebox.showinfo(
          "Replay Saved!", f"Instant replay successfully saved to:\n{filename}"
      )
    except Exception as e:
      messagebox.showerror("Export Error", f"Failed to save replay: {e}")

  def toggle_recorder():
    if not recorder_state["running"]:
      if not HAS_RECORDER_DEPS:
        messagebox.showerror(
            "Missing Dependencies",
            "Please install mss and opencv-python via pip!",
        )
        return
      recorder_state["running"] = True
      recorder_state["thread"] = threading.Thread(
          target=buffer_worker, daemon=True
      )
      recorder_state["thread"].start()

      status_var.set("Status: ACTIVE (Buffering Last 1 Min...)")
      status_lbl.config(fg="#00ffb3")
      start_btn.config(text="⏹ STOP BUFFER", bg="#382127", fg="#ff5555")

      # Register global hotkey if available
      if HAS_KEYBOARD:
        hotkey_str = hk_entry.get().strip()
        try:
          keyboard.add_hotkey(hotkey_str, save_replay)
        except Exception:
          pass
    else:
      recorder_state["running"] = False
      if HAS_KEYBOARD:
        try:
          keyboard.unhook_all()
        except Exception:
          pass

      status_var.set("Status: INACTIVE (Buffer Stopped)")
      status_lbl.config(fg="#ff5555")
      start_btn.config(text="▶ START BUFFER RECORDER", bg="#212738", fg="#00ffb3")

  # 4. Buttons Layout
  btn_frame = tk.Frame(controls_frame, bg="#161925")
  btn_frame.pack(anchor="w", pady=10)

  start_btn = tk.Button(
      btn_frame,
      text="▶ START BUFFER RECORDER",
      command=toggle_recorder,
      bg="#212738",
      fg="#00ffb3",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  start_btn.pack(side="left", padx=(0, 10))

  save_btn = tk.Button(
      btn_frame,
      text="💾 SAVE REPLAY NOW",
      command=save_replay,
      bg="#212738",
      fg="#00d2ff",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  save_btn.pack(side="left", padx=5)