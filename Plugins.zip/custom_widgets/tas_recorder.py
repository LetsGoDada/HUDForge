import os
import time
import tkinter as tk
from tkinter import messagebox, ttk

try:
  from pynput import keyboard, mouse

  HAS_PYNPUT = True
except ImportError:
  HAS_PYNPUT = False


def register(app, sub_notebook):
  # 1. Create the sub-tab inside Custom Hub
  tab = tk.Frame(sub_notebook, bg="#161925")
  sub_notebook.add(tab, text="🔴 Input Recorder")

  # Register for global theme sync with HUD Customizer
  if hasattr(app, "register_theme_frame"):
    app.register_theme_frame(tab)

  # 2. Title & Description
  title_lbl = tk.Label(
      tab,
      text="Universal Input Recorder (LLI / TAS Logger)",
      fg="#00d2ff",
      bg="#161925",
      font=("Consolas", 11, "bold"),
  )
  title_lbl.pack(anchor="w", padx=15, pady=(15, 5))

  desc_text = (
      "Capture global mouse and keyboard actions into LLI-compatible logs for"
      " TAS playback."
  )
  if not HAS_PYNPUT:
    desc_text += (
        "\n⚠️ Warning: 'pynput' is missing. Run: pip install pynput"
    )

  desc_lbl = tk.Label(
      tab,
      text=desc_text,
      fg="#ff9999" if not HAS_PYNPUT else "#8f9ba8",
      bg="#161925",
      font=("Segoe UI", 9),
      justify="left",
  )
  desc_lbl.pack(anchor="w", padx=15, pady=(0, 15))

  # 3. Controls Container
  controls_frame = tk.Frame(tab, bg="#161925")
  controls_frame.pack(anchor="w", padx=15, pady=5)

  # Status Indicator
  status_var = tk.StringVar(value="Status: IDLE (Not Recording)")
  status_lbl = tk.Label(
      controls_frame,
      textvariable=status_var,
      fg="#ff5555",
      bg="#161925",
      font=("Consolas", 9, "bold"),
  )
  status_lbl.pack(anchor="w", pady=(0, 10))

  # Options Frame
  opts_frame = tk.Frame(controls_frame, bg="#161925")
  opts_frame.pack(anchor="w", pady=5)

  move_var = tk.BooleanVar(value=False)
  move_chk = tk.Checkbutton(
      opts_frame,
      text="Record Mouse Movement (High Volume)",
      variable=move_var,
      bg="#161925",
      fg="#e0e6ed",
      selectcolor="#12151e",
      activebackground="#161925",
      activeforeground="#ffffff",
      font=("Consolas", 9),
  )
  move_chk.pack(anchor="w", pady=2)

  clicks_var = tk.BooleanVar(value=True)
  clicks_chk = tk.Checkbutton(
      opts_frame,
      text="Record Mouse Clicks & Scroll",
      variable=clicks_var,
      bg="#161925",
      fg="#e0e6ed",
      selectcolor="#12151e",
      activebackground="#161925",
      activeforeground="#ffffff",
      font=("Consolas", 9),
  )
  clicks_chk.pack(anchor="w", pady=2)

  keys_var = tk.BooleanVar(value=True)
  keys_chk = tk.Checkbutton(
      opts_frame,
      text="Record Keyboard Presses",
      variable=keys_var,
      bg="#161925",
      fg="#e0e6ed",
      selectcolor="#12151e",
      activebackground="#161925",
      activeforeground="#ffffff",
      font=("Consolas", 9),
  )
  keys_chk.pack(anchor="w", pady=2)

  # Recorder Engine State
  rec_state = {
      "recording": False,
      "session_start": 0,
      "log_buffer": [],
      "mouse_listener": None,
      "key_listener": None,
  }

  def get_timestamp(start_time):
    elapsed = time.time() - start_time
    return f"{int(elapsed // 3600):02d}:{int((elapsed % 3600) // 60):02d}:{elapsed % 60:06.3f}"

  def log_event(event_type, details):
    if not rec_state["recording"]:
      return
    ts = get_timestamp(rec_state["session_start"])
    line = f"[{ts}] | {event_type:<18} | {details}"
    rec_state["log_buffer"].append(line + "\n")

  # Listeners
  def on_move(x, y):
    if move_var.get():
      log_event("MOUSE_MOVE", f"X: {x}, Y: {y}")

  def on_click(x, y, button, pressed):
    if clicks_var.get():
      state = "DOWN" if pressed else "UP"
      log_event(f"MOUSE_{button.name.upper()}_{state}", f"X: {x}, Y: {y}")

  def on_scroll(x, y, dx, dy):
    if clicks_var.get():
      direction = "UP" if dy > 0 else "DOWN"
      log_event("MOUSE_SCROLL", f"Direction: {direction} (X: {x}, Y: {y})")

  def on_press(key):
    if keys_var.get():
      try:
        k_name = key.char if key.char else str(key)
      except AttributeError:
        k_name = str(key)
      log_event("KEY_DOWN", f"Physical: {k_name}")

  def on_release(key):
    if keys_var.get():
      try:
        k_name = key.char if key.char else str(key)
      except AttributeError:
        k_name = str(key)
      log_event("KEY_UP", f"Physical: {k_name}")

  def toggle_recording():
    if not HAS_PYNPUT:
      messagebox.showerror(
          "Missing Dependency", "Please install pynput: pip install pynput"
      )
      return

    if not rec_state["recording"]:
      # Start Recording
      rec_state["recording"] = True
      rec_state["session_start"] = time.time()
      rec_state["log_buffer"] = []

      # Header
      rec_state["log_buffer"].append(
          "====================================================================\n"
      )
      rec_state["log_buffer"].append(
          "           HUDFORGE DYNAMIC INPUT RECORDER VAULT                     \n"
      )
      rec_state["log_buffer"].append(
          f" Session Initialized: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
      )
      rec_state["log_buffer"].append(
          "====================================================================\n"
      )

      rec_state["mouse_listener"] = mouse.Listener(
          on_move=on_move, on_click=on_click, on_scroll=on_scroll
      )
      rec_state["key_listener"] = keyboard.Listener(
          on_press=on_press, on_release=on_release
      )

      rec_state["mouse_listener"].start()
      rec_state["key_listener"].start()

      status_var.set("Status: RECORDING (Capturing Inputs...)")
      status_lbl.config(fg="#00ffb3")
      rec_btn.config(text="⏹ STOP & SAVE RECORDING", bg="#382127", fg="#ff5555")
    else:
      # Stop Recording & Save
      rec_state["recording"] = False
      if rec_state["mouse_listener"]:
        rec_state["mouse_listener"].stop()
      if rec_state["key_listener"]:
        rec_state["key_listener"].stop()

      filename = f"HUDForge_Recording_{int(time.time())}.txt"
      try:
        with open(filename, "w", encoding="utf-8") as f:
          f.writelines(rec_state["log_buffer"])
        messagebox.showinfo(
            "Saved",
            f"Recording successfully saved to:\n{os.path.abspath(filename)}",
        )
      except Exception as e:
        messagebox.showerror("Error", f"Failed to save recording: {e}")

      status_var.set("Status: IDLE (Not Recording)")
      status_lbl.config(fg="#ff5555")
      rec_btn.config(text="🔴 START RECORDING", bg="#212738", fg="#00ffb3")

  # 4. Button Layout
  btn_frame = tk.Frame(controls_frame, bg="#161925")
  btn_frame.pack(anchor="w", pady=10)

  rec_btn = tk.Button(
      btn_frame,
      text="🔴 START RECORDING",
      command=toggle_recording,
      bg="#212738",
      fg="#00ffb3",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  rec_btn.pack(anchor="w")