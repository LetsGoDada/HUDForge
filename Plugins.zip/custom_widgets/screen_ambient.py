import threading
import time
import tkinter as tk
from tkinter import messagebox

try:
  import cv2
  import mss
  import numpy as np
  from PIL import Image, ImageTk

  HAS_AMBIENT_DEPS = True
except ImportError:
  HAS_AMBIENT_DEPS = False


def register(app, sub_notebook):
  tab = tk.Frame(sub_notebook, bg="#161925")
  sub_notebook.add(tab, text="💡 Screen Ambient Light")

  if hasattr(app, "register_theme_frame"):
    app.register_theme_frame(tab)

  title_lbl = tk.Label(
      tab,
      text="Screen 3 Ambient Light Engine (Smooth Gradient)",
      fg="#00d2ff",
      bg="#161925",
      font=("Consolas", 11, "bold"),
  )
  title_lbl.pack(anchor="w", padx=15, pady=(15, 5))

  desc_text = (
      "Zero-lag ambient engine with smooth gradient interpolation for Screens"
      " 1 & 2."
  )
  if not HAS_AMBIENT_DEPS:
    desc_text += "\n⚠️ Warning: Missing deps. Run: pip install mss opencv-python numpy Pillow"

  desc_lbl = tk.Label(
      tab,
      text=desc_text,
      fg="#ff9999" if not HAS_AMBIENT_DEPS else "#8f9ba8",
      bg="#161925",
      font=("Segoe UI", 9),
      justify="left",
  )
  desc_lbl.pack(anchor="w", padx=15, pady=(0, 15))

  controls_frame = tk.Frame(tab, bg="#161925")
  controls_frame.pack(anchor="w", padx=15, pady=5)

  status_var = tk.StringVar(value="Status: AMBIENT ENGINE INACTIVE")
  status_lbl = tk.Label(
      controls_frame,
      textvariable=status_var,
      fg="#ff5555",
      bg="#161925",
      font=("Consolas", 9, "bold"),
  )
  status_lbl.pack(anchor="w", pady=(0, 10))

  # Preview Canvas
  color_display = tk.Canvas(
      controls_frame,
      width=300,
      height=80,
      bg="#12151e",
      highlightthickness=1,
      highlightbackground="#212738",
  )
  color_display.pack(anchor="w", pady=(0, 10))
  prev_image_container = [None]
  prev_canvas_img = color_display.create_image(0, 0, anchor="nw", image=None)

  color_label = color_display.create_text(
      150,
      40,
      text="Warte auf Start...",
      fill="#ffffff",
      font=("Consolas", 8, "bold"),
  )

  overlay_var = tk.BooleanVar(value=True)
  overlay_chk = tk.Checkbutton(
      controls_frame,
      text="Instant Smooth Gradient Sync (Screen 1 & 2)",
      variable=overlay_var,
      bg="#161925",
      fg="#e0e6ed",
      selectcolor="#12151e",
      activebackground="#161925",
      activeforeground="#ffffff",
      font=("Consolas", 9),
  )
  overlay_chk.pack(anchor="w", pady=(0, 15))

  ambient_state = {
      "running": False,
      "left_colors": [],
      "right_colors": [],
      "full_colors": [],
      "overlay_windows": [],
  }

  def create_overlay_windows(monitors):
    destroy_overlays()
    if len(monitors) <= 3:
      return

    target_indices = [1, 2]  # Screen 1 & Screen 2

    for idx in target_indices:
      if idx >= len(monitors):
        continue
      mon = monitors[idx]

      top = tk.Toplevel(tab)
      top.overrideredirect(True)
      top.attributes("-topmost", True)
      try:
        top.attributes("-alpha", 0.3)
      except Exception:
        pass

      x, y, w, h = mon["left"], mon["top"], mon["width"], mon["height"]
      top.geometry(f"{w}x{h}+{x}+{y}")

      canvas = tk.Canvas(
          top, width=w, height=h, bg="#161925", highlightthickness=0
      )
      canvas.pack(fill="both", expand=True)
      img_ref = [None]
      img_id = canvas.create_image(0, 0, anchor="nw", image=None)

      ambient_state["overlay_windows"].append(
          (top, canvas, img_id, img_ref, idx)
      )

  def destroy_overlays():
    for item in ambient_state["overlay_windows"]:
      try:
        item[0].destroy()
      except Exception:
        pass
    ambient_state["overlay_windows"].clear()

  def generate_smooth_gradient(colors_rgb, target_width, target_height):
    """Erzeugt einen butterweichen Farbverlauf mittels Bilinearer Interpolation (Resampling.BILINEAR)"""
    if not colors_rgb:
      return Image.new(
          "RGB", (target_width, target_height), (22, 25, 37)
    )

    # Erstelle eine Mini-Basis mit den Farb-Samples
    base = Image.new("RGB", (len(colors_rgb), 1))
    pixels = base.load()
    for i, col in enumerate(colors_rgb):
      pixels[i, 0] = col

    # BILINEAR sorgt für den fließenden, weichen Übergang statt harten Blöcken!
    return base.resize(
        (target_width, target_height), Image.Resampling.BILINEAR
    )

  def ambient_worker():
    with mss.mss() as sct:
      monitors = sct.monitors
      if len(monitors) <= 3:
        return
      target_monitor = monitors[3]

      while ambient_state["running"]:
        try:
          img = np.array(sct.grab(target_monitor))
          frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

          small = cv2.resize(frame, (64, 36))
          sf_h, sf_w, _ = small.shape

          left_half = small[:, : sf_w // 2]
          right_half = small[:, sf_w // 2 :]

          def get_fast_samples(sub_frame, num_samples=8):
            # Mehr Samples (8 statt 4) für noch fließendere Farbübergänge
            cols = []
            s_w = sub_frame.shape[1] // num_samples
            for s in range(num_samples):
              x1 = s * s_w
              x2 = (
                  (s + 1) * s_w if s < num_samples - 1 else sub_frame.shape[1]
              )
              sec = sub_frame[:, x1:x2]
              avg = np.average(np.average(sec, axis=0), axis=0)
              cols.append((int(avg[2]), int(avg[1]), int(avg[0])))
            return cols

          ambient_state["left_colors"] = get_fast_samples(left_half, 8)
          ambient_state["right_colors"] = get_fast_samples(right_half, 8)
          ambient_state["full_colors"] = get_fast_samples(small, 10)

        except Exception as e:
          print(f"[Worker Error] {e}")

        time.sleep(0.01)

  def update_ui_loop():
    if not ambient_state["running"]:
      return

    try:
      left_c = ambient_state["left_colors"]
      right_c = ambient_state["right_colors"]
      full_c = ambient_state["full_colors"]

      if left_c and right_c and full_c:
        # Vorschau im Custom Hub aktualisieren (weicher Verlauf)
        pil_prev = generate_smooth_gradient(full_c, 300, 80)
        img_tk_prev = ImageTk.PhotoImage(pil_prev)
        prev_image_container[0] = img_tk_prev
        color_display.itemconfig(prev_canvas_img, image=prev_image_container[0])
        color_display.itemconfig(
            color_label, text="SMOOTH GRADIENT ACTIVE", fill="#00ffb3"
        )

        if overlay_var.get():
          for win, cvs, img_id, img_ref, m_idx in ambient_state[
              "overlay_windows"
          ]:
            source_colors = left_c if m_idx == 1 else right_c
            w = win.winfo_width() or 480
            h = win.winfo_height() or 270
            
            # Generiert den weichen Farbverlauf skaliert auf die echte Bildschirmgröße
            pil_side = generate_smooth_gradient(source_colors, w, h)
            img_tk_side = ImageTk.PhotoImage(pil_side)
            img_ref[0] = img_tk_side
            cvs.itemconfig(img_id, image=img_ref[0])

    except Exception as e:
      print(f"[UI Update Error] {e}")

    tab.after(33, update_ui_loop)

  def toggle_ambient():
    if not HAS_AMBIENT_DEPS:
      messagebox.showerror(
          "Fehlende Bibliotheken",
          "Bitte installiere: pip install mss opencv-python numpy Pillow",
      )
      return

    if not ambient_state["running"]:
      ambient_state["running"] = True

      if overlay_var.get():
        with mss.mss() as sct:
          create_overlay_windows(sct.monitors)

      t = threading.Thread(target=ambient_worker, daemon=True)
      t.start()

      update_ui_loop()

      status_var.set("Status: SMOOTH ENGINE ACTIVE")
      status_lbl.config(fg="#00ffb3")
      start_btn.config(text="⏹ STOP AMBIENT LIGHT", bg="#382127", fg="#ff5555")
    else:
      ambient_state["running"] = False
      destroy_overlays()
      status_var.set("Status: AMBIENT ENGINE INACTIVE")
      status_lbl.config(fg="#ff5555")
      start_btn.config(text="▶ START AMBIENT LIGHT", bg="#212738", fg="#00ffb3")

  btn_frame = tk.Frame(controls_frame, bg="#161925")
  btn_frame.pack(anchor="w", pady=5)

  start_btn = tk.Button(
      btn_frame,
      text="▶ START AMBIENT LIGHT",
      command=toggle_ambient,
      bg="#212738",
      fg="#00ffb3",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  start_btn.pack(anchor="w")