import subprocess
import sys
import os
import tkinter as tk


def register(sub_notebook):
  # 1. Create a sub-tab inside the Custom Hub for the wave tool
  tab = tk.Frame(sub_notebook, bg="#161925")
  sub_notebook.add(tab, text="🌊 Wave Overlay")

  # 2. Title & Description
  title_lbl = tk.Label(
      tab,
      text="Wave Effect Overlay",
      fg="#00d2ff",
      bg="#161925",
      font=("Consolas", 11, "bold"),
  )
  title_lbl.pack(anchor="w", padx=15, pady=(15, 5))

  desc_lbl = tk.Label(
      tab,
      text=(
          "Launches a full-screen semi-transparent wave overlay.\nPress ESC"
          " or click the close button inside the overlay to disable it."
      ),
      fg="#8f9ba8",
      bg="#161925",
      font=("Segoe UI", 9),
      justify="left",
  )
  desc_lbl.pack(anchor="w", padx=15, pady=(0, 15))

  # 3. Launch Function
  def launch_wave_app():
    # Runs the wave overlay script as an independent process
    script_path = os.path.abspath(__file__)
    # If run standalone or via subprocess, we can trigger the wave window class
    # Let's spawn the standalone window loop directly:
    try:
      # Spawn the overlay window loop in a separate process window
      subprocess.Popen([sys.executable, "-c", STANDALONE_WAVE_CODE])
    except Exception as e:
      print(f"[WaveWidget Error] Failed to launch: {e}")

  # 4. Launch Button
  launch_btn = tk.Button(
      tab,
      text="▶ LAUNCH WAVE OVERLAY",
      command=launch_wave_app,
      bg="#212738",
      fg="#00ffb3",
      activebackground="#2a3248",
      activeforeground="#ffffff",
      font=("Consolas", 9, "bold"),
      bd=0,
      padx=12,
      pady=6,
      cursor="hand2",
  )
  launch_btn.pack(anchor="w", padx=15, pady=5)


# =====================================================================
# Standalone Wave Animation Logic (Executed when launched from the button)
# =====================================================================
STANDALONE_WAVE_CODE = """
import tkinter as tk

class WaveOverlayApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("HUDForge // Wave Overlay App")
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-alpha", 0.4)
        self.root.configure(bg="#08090d")
        self.root.bind("<Escape>", lambda e: self.close())

        self.canvas = tk.Canvas(self.root, bg="#08090d", highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)

        self.close_btn = tk.Button(
            self.root, text="✕ CLOSE WAVE APP", command=self.close,
            bg="#ff5555", fg="#ffffff", font=("Consolas", 9, "bold"),
            bd=0, padx=12, pady=6, cursor="hand2"
        )
        self.close_btn.place(x=20, y=20)

        self.width = self.root.winfo_screenwidth()
        self.height = self.root.winfo_screenheight()
        self.center_x = self.width // 2
        self.center_y = self.height // 2

        self.ripples = []
        self.animating = True
        self.spawn_ripple()
        self.update_animation()

    def spawn_ripple(self):
        if not self.animating: return
        self.ripples.append({
            "x": self.center_x, "y": self.center_y,
            "radius": 10, "max_radius": max(self.width, self.height) * 0.8
        })
        self.root.after(800, self.spawn_ripple)

    def update_animation(self):
        if not self.animating: return
        self.canvas.delete("all")
        surviving = []
        for r in self.ripples:
            r["radius"] += 6
            progress = r["radius"] / r["max_radius"]
            if progress < 1:
                surviving.append(r)
                alpha = 1 - progress
                self.canvas.create_oval(
                    r["x"] - r["radius"], r["y"] - r["radius"],
                    r["x"] + r["radius"], r["y"] + r["radius"],
                    outline="#00d2ff", width=max(1, int(4 * alpha))
                )
        self.ripples = surviving
        self.root.after(30, self.update_animation)

    def close(self):
        self.animating = False
        self.root.destroy()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    WaveOverlayApp().run()
"""